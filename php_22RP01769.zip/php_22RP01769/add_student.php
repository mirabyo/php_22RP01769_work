<?php
$fErr = $lErr = "";
session_start();
include('config.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Validation
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = test_input($_POST['first_name']);
    $last_name = test_input($_POST['last_name']);
    $birthdate = $_POST['birthdate'];
    $gender = $_POST['gender'];
    $class = test_input($_POST['class']);
    $department = test_input($_POST['department']);

    if (empty($first_name)) {
        $fErr = "First name is required";
    } elseif (!preg_match("/^[a-zA-Z]*$/", $first_name)) {
        $fErr = "Only letters allowed";
    }

    if (empty($last_name)) {
        $lErr = "Last name is required";
    } elseif (!preg_match("/^[a-zA-Z]*$/", $last_name)) {
        $lErr = "Only letters allowed";
    }

    // If there are no validation errors, insert data into database
    if (empty($fErr) && empty($lErr)) {
        if (isset($_POST['insert'])) {
            $query = "INSERT INTO students (first_name, last_name, birthdate, gender, class, department)
                      VALUES ('$first_name', '$last_name', '$birthdate', '$gender', '$class', '$department')";
            if (mysqli_query($conn, $query)) {
                echo "Student added successfully.";
            } else {
                echo "Error: " . mysqli_error($conn);
            }
        }
    }
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (isset($_POST['view'])) {
    $query = "SELECT * FROM students";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        die('Query Failed: ' . mysqli_error($conn));
    }
    echo "<table border='1'>
        <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Birthdate</th>
            <th>Gender</th>
            <th>Class</th>
            <th>Department</th>
            <th>Actions</th>
        </tr>";
    while ($st = mysqli_fetch_assoc($result)) {
        echo "<tr>
            <td>" . $st['id'] . "</td>
            <td>" . $st['first_name'] . "</td>
            <td>" . $st['last_name'] . "</td>
            <td>" . $st['birthdate'] . "</td>
            <td>" . $st['gender'] . "</td>
            <td>" . $st['class'] . "</td>
            <td>" . $st['department'] . "</td>
            <td>
                <a href='edit_student.php?id=" . $st['id'] . "'>Edit</a>
                <a href='delete_student.php?id=" . $st['id'] . "'>Delete</a>
            </td>
        </tr>";
    }
    echo "</table>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Student</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <form method="POST" action="">
        <h2>Add Student &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="logout.php">Logout</a></h2>
        <label for="first_name">First Name:</label><span style="color: red;">*<?php echo $fErr; ?></span>
        <input type="text" id="first_name" name="first_name">
        
        
        <label for="last_name">Last Name:</label><span style="color:red;">*<?php echo $lErr; ?></span>
        <input type="text" id="last_name" name="last_name">
        

        <label for="birthdate">Birthdate:</label>
        <input type="date" id="birthdate" name="birthdate">

        <label for="department">Department:</label>
        <input type="text" id="department" name="department">
        
        <label for="gender">Gender:</label>
        <select id="gender" name="gender">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select>
        
        <label for="class">Class:</label>
        <input type="text" id="class" name="class">
        
        <button type="submit" name="insert">Add Student</button>
        <button type="submit" name="view">View Students</button>
    </form>
</body>
</html>
