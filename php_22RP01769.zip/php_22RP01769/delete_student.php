<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get student ID from the query string
$student_id = $_GET['id'];

// Delete the student record
$query = "DELETE FROM students WHERE id = $student_id";

if (mysqli_query($conn, $query)) {
   header("location:add_student.php");
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
